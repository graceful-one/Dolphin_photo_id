Alejandra Rios 
email: ar718@duke.edu github: alerios3

This code allows the user to input data into the database. 
A Bonehendge Whale Center user is able to pick the following: 

dolphin id number
fin code
name
identify it as dead or alive
give the date, write comments
pick a family (1st, second, third)
a print option 
central catalog number
manteo match
pick location (virginia beach, wilmington, ocracoke)
CCU match 
known male
known female
seen by trawler
s_GUID
Hatteras Match
Bad or Bad.1
No Left Photo
No Right Photo
Best of Project Done
Better Left Photo
Better Right Photo
Cull this dolphin
scan picture
Change to 
Notes
Distinctiveness
Missing Date
Other
