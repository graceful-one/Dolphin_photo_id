import streamlit as st
import pandas as pd 

st.page_link("your_app.py", label="Dolphin Query")
st.page_link("photo_query.py", label="Picture app")
#st.page_link("pages/page_2.py", label="update data")

#import geopandas as gpd 
st.title("Home Page")

